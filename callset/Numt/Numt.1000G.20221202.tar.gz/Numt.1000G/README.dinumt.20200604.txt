Mills Lab dinumt NumtS callset
Delivered by Weichen (Arthur) Zhou
===================

I. Software versions and parameters
-----------------------------------
- dinumt (https://github.com/mills-lab/dinumt)
  - Version: 0.0.23
  - Parameters:
    - dinumt.cram.pl --mask_filename=refNumts.38.bed --input_filename=${sample}.final.cram --reference=GRCh38_full_analysis_set_plus_decoy_hla.fa --min_reads_cluster=1 --include_mask --mt_names=chrM --output_filename=${sample}.final.vcf --prefix=${sample}.final --len_cluster_include=${len_cluster_include} --len_cluster_link=${len_cluster_link} --insert_size=${insert_size} --max_read_cov=${max_read_cov} --output_support --support_filename=${sample}.final_support.sam
	- gnomit.38.cram.pl --input_filename=merged.vcf --mask_filename=refNumts.38.bed --info_filename=sampleInfo --output_filename=merged_geno.vcf --samtools=samtools --reference=GRCh38_full_analysis_set_plus_decoy_hla.fa --min_map_qual=10 --dir_tmp=/tmp --exonerate=exonerate --mt_filename=MT.fa
	
II. Delivered files
-------------------
- Merged sample vcf (sorted, bgzip & tabix indexed)
  - ALL.dinumt.NumtS.1000G.HC.20200604.gt.vcf.gz
  - ALL.dinumt.NumtS.1000G.HC.20200604.gt.vcf.gz.tbi

